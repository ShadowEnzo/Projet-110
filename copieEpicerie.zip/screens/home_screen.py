from kivy.uix.screenmanager import Screen
from kivy.lang import Builder

Builder.load_file("kv/home_screen.kv")

class HomeScreen(Screen):
    pass
